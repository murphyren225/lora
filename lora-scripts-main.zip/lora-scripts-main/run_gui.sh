#!/bin/bash

export HF_HOME=huggingface
export PYTHONUTF8=1

python gui.py "$@"

