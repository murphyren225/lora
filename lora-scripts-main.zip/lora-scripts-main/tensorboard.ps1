$Env:TF_CPP_MIN_LOG_LEVEL = "3"

.\venv\Scripts\activate
tensorboard --logdir=logs