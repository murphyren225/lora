from . import application

app = application.app